#ifndef ORDONNANCEURBINAIRE_H_INCLUDED
#define ORDONNANCEURBINAIRE_H_INCLUDED
#include "Ordonnanceur.h"
class OrdonnanceurBinaire:public Ordonnanceur{
    public:
        void ordonnancer(StatBinary donnesReq);
};
void OrdonnanceurBinaire(StatBinary donnesReq){

}
#endif // ORDONNANCEURBINAIRE_H_INCLUDED
