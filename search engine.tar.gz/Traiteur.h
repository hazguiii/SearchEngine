#ifndef TRAITEUR_H_INCLUDED
#define TRAITEUR_H_INCLUDED
class Traiteur{
    virtual vector<string> traiter(vector<string> mots) = 0; //joue le role d'un nettoyeur
};

#endif // TRAITEUR_H_INCLUDED
